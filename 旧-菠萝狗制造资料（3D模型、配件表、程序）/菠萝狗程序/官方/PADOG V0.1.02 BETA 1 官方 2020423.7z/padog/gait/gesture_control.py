#===头===
#1==-==2
#4==-==3
R_H=100

#4条腿坐标同时调节
def control_4_legs(x,y):
    global y1,y2,y3,y4
    global x1,x2,x3,x4
    y1 = y
    y2 = y
    y3 = y
    y4 = y
    x1=x
    x2=x
    x3=x
    x4=x

    
    caculate()
    servo_output()

#高度调节函数
def height(goal):
    global y1,y2,y3,y4
    global x1,x2,x3,x4
    global R_H
    global ges_y_1,ges_y_2,ges_y_3,ges_y_4
    while True:
        if R_H>goal:
            R_H=R_H-abs(R_H-goal)*Kp_H
        elif R_H<goal:
            R_H=R_H+abs(R_H-goal)*Kp_H
        if abs(R_H-goal)<1:
            break
        print("高度坐标",R_H)
        y1 = -R_H
        y2 = -R_H
        y3 = -R_H
        y4 = -R_H
        
        ges_y_1 = -R_H
        ges_y_2 = -R_H
        ges_y_3 = -R_H
        ges_y_4 = -R_H
        x1=0
        x2=0
        x3=0
        x4=0

    
        caculate()
        servo_output()
    
   

                    