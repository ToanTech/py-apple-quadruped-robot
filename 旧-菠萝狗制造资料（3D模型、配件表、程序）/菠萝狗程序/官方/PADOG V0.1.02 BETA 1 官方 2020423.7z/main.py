import padog
import time

time.sleep(1)           #延时等待
padog.height(50)        #调节高度到50mm
padog.height(110)       #调节高度到110mm
padog.height(50)        #调节高度到50mm
padog.height(110)       #调节高度到110mm
time.sleep(1)           #延时等待
padog.trot(5)           #往前进5步
time.sleep(1)           #延时等待
padog.trot(-5)          #往后退5步
