import time
from math import *
from machine import I2C
from machine import UART
#from machine import Pin
import ustruct

#==============版本信息==================#
version="V0.1.02 BETA 1 2020423"

#打印版本信息
print("=============================")
print("PY-APPLE DOG TEST VER "+version)
print("=============================")
print("作者：灯哥  ream_d@yeah.net    开源协议：Apache License")
print("=========实现功能=========")
print("1、踏步 2、高度调节 3、小跑基础版（向前、向后）")
print("=========实现功能=========")

#=============默认速度 步长 设置=============
l1=80   #大腿长(mm)
l2=70   #小腿长(mm)
h=50    #抬腿高度 设置
xf=30
xs=-10
#xf=0
#xs=0
Ts=1   #周期
faai=0.5   #占空比
speed=0.025  #步频调节
#=============校准模式 设置=============
foot_init=0

#=============默认舵机中位值设置=============
#狗腿子顺序(从1开始顺时针数)
#===头===
#===头===
#1==-==2
#4==-==3
init_1h = 90   #1脚大腿
init_1s = 113   #1脚小腿

init_2h = 105   #2脚大腿
init_2s = 97  #2脚小腿

init_3h = 87   #3脚大腿
init_3s = 85   #3脚小腿

init_4h = 76   #4脚大腿
init_4s = 105   #4脚小腿

#=============PCA9685舵机控制板=============
pcai2c = I2C(I2C.I2C0, mode=I2C.MODE_MASTER, scl=28, sda=29, freq=100000)

#=============高度调节比例系数=============
Kp_H=0.03
#=============一些中间变量=============
t=0
init_x=0
init_y=-100
x1=init_x
y1=init_y
x2=init_x

y2=init_y
x3=init_x
y3=init_y
x4=init_x
y4=init_y

ges_x_1=0
ges_x_2=0
ges_x_3=0
ges_x_4=0

ges_y_1=init_y
ges_y_2=init_y
ges_y_3=init_y
ges_y_4=init_y


class PCA9685:
    def __init__(self, i2c, address=0x40):
        self.i2c = i2c
        self.address = address
        self.reset()

    def _write(self, address, value):
        self.i2c.writeto_mem(self.address, address, bytearray([value]))

    def _read(self, address):
        return self.i2c.readfrom_mem(self.address, address, 1)[0]

    def reset(self):
        self._write(0x00, 0x00) # Mode1

    def freq(self, freq=None):
        if freq is None:
            return int(25000000.0 / 4096 / (self._read(0xfe) - 0.5))
        prescale = int(25000000.0 / 4096.0 / freq + 0.5)
        old_mode = self._read(0x00) # Mode 1
        self._write(0x00, (old_mode & 0x7F) | 0x10) # Mode 1, sleep
        self._write(0xfe, prescale) # Prescale
        self._write(0x00, old_mode) # Mode 1
        time.sleep_us(5)
        self._write(0x00, old_mode | 0xa1) # Mode 1, autoincrement on

    def pwm(self, index, on=None, off=None):
        if on is None or off is None:
            data = self.i2c.readfrom_mem(self.address, 0x06 + 4 * index, 4)
            return ustruct.unpack('<HH', data)
        data = ustruct.pack('<HH', on, off)
        self.i2c.writeto_mem(self.address, 0x06 + 4 * index,  data)

    def duty(self, index, value=None, invert=False):
        if value is None:
            pwm = self.pwm(index)
            if pwm == (0, 4096):
                value = 0
            elif pwm == (4096, 0):
                value = 4095
            value = pwm[1]
            if invert:
                value = 4095 - value
            return value
        if not 0 <= value <= 4095:
            raise ValueError("Out of range")
        if invert:
            value = 4095 - value
        if value == 0:
            self.pwm(index, 0, 4096)
        elif value == 4095:
            self.pwm(index, 4096, 0)
        else:
            self.pwm(index, 0, value)


#======运动学逆解======
def caculate():

    global x1,y1,x2,y2,x3,y3,x4,y4
    global ham1,ham2,ham3,ham4
    global shank1,shank2,shank3,shank4
    #腿1
    x1=-x1
    shank1=pi-acos((x1*x1+y1*y1-l1*l1-l2*l2)/(-2*l1*l2))
    fai1=acos((l1*l1+x1*x1+y1*y1-l2*l2)/(2*l1*sqrt(x1*x1+y1*y1)))
    if x1>0:
        ham1=abs(atan(y1/x1))-fai1
    elif x1<0:
        ham1=pi-abs(atan(y1/x1))-fai1
    else:
        ham1=pi-1.5707-fai1
    shank1=180*shank1/pi
    ham1=180*ham1/pi
    '''
    print('ham1:',ham1)
    print('shank1:',shank1)
    '''
    #腿2
    x2=-x2
    shank2=pi-acos((x2*x2+y2*y2-l1*l1-l2*l2)/(-2*l1*l2))
    fai2=acos((l1*l1+x2*x2+y2*y2-l2*l2)/(2*l1*sqrt(x2*x2+y2*y2)))
    if x2>0:
        ham2=abs(atan(y2/x2))-fai2
    elif x2<0:
        ham2=pi-abs(atan(y2/x2))-fai2
    else:
        ham2=pi-1.5707-fai2
    shank2=180*shank2/pi
    ham2=180*ham2/pi
    '''
    print('ham2:',ham2)
    print('shank2:',shank2)
    '''
    #腿3
    x3=-x3
    shank3=pi-acos((x3*x3+y3*y3-l1*l1-l2*l2)/(-2*l1*l2))
    fail3=acos((l1*l1+x3*x3+y3*y3-l2*l2)/(2*l1*sqrt(x3*x3+y3*y3)))
    if x3>0:
        ham3=abs(atan(y3/x3))-fail3
    elif x3<0:
        ham3=pi-abs(atan(y3/x3))-fail3
    else:
        ham3=pi-1.5707-fail3
    shank3=180*shank3/pi
    ham3=180*ham3/pi
    '''
    print('ham3:',ham3)
    print('shank3:',shank3)
    '''
    #腿4
    x4=-x4
    shank4=pi-acos((x4*x4+y4*y4-l1*l1-l2*l2)/(-2*l1*l2))
    fai4=acos((l1*l1+x4*x4+y4*y4-l2*l2)/(2*l1*sqrt(x4*x4+y4*y4)))
    if x4>0:
        ham4=abs(atan(y4/x4))-fai4
    elif x4<0:
        ham4=pi-abs(atan(y4/x4))-fai4
    else:
        ham4=pi-1.5707-fai4
    shank4=180*shank4/pi
    ham4=180*ham4/pi
    '''
    print('ham4:',ham4)
    print('shank4:',shank4)
    '''
#======舵机输出======
#狗腿子顺序(从1开始顺时针数)
#===头===
#1==-==2
#4==-==3
def servo_output():
    if foot_init==0:
        #腿1
        servos.position(4, degrees=init_1h-ham1)  # 腿1大腿
        servos.position(5, degrees=(init_1s-90)+shank1)  # 腿1小腿
        #腿2
        servos.position(6, degrees=init_2h+ham2)  # 腿2大腿
        servos.position(7, degrees=(init_2s+90)-shank2)  # 腿2小腿
        #腿3
        servos.position(8, degrees=init_3h+ham3)  # 腿3大腿
        servos.position(9, degrees=(init_3s+90)-shank3)  # 腿3小腿
        #腿4
        servos.position(10, degrees=init_4h-ham4)  # 腿4大腿
        servos.position(11, degrees=(init_4s-90)+shank4)  # 腿4小腿
    else:
        #腿1
        servos.position(4, degrees=init_1h)  # 腿1大腿
        servos.position(5, degrees=init_1s)  # 腿1小腿
        #腿2
        servos.position(6, degrees=init_2h)  # 腿2大腿
        servos.position(7, degrees=init_2s)  # 腿2小腿
        #腿3
        servos.position(8, degrees=init_3h)  # 腿3大腿
        servos.position(9, degrees=init_3s)  # 腿3小腿
        #腿4
        servos.position(10, degrees=init_4h)  # 腿4大腿
        servos.position(11, degrees=init_4s)  # 腿4小腿


class Servos:
    def __init__(self, i2c, address=0x40, freq=50, min_us=500, max_us=2500,  #根据舵机参数自行设置
                 degrees=180):
        self.period = 1000000 / freq
        self.min_duty = self._us2duty(min_us)
        self.max_duty = self._us2duty(max_us)
        self.degrees = degrees
        self.freq = freq
        self.pca9685 = PCA9685(i2c, address)
        self.pca9685.freq(freq)



    def _us2duty(self, value):
        return int(4095 * value / self.period)

    def position(self, index, degrees=None, radians=None, us=None, duty=None):
        span = self.max_duty - self.min_duty
        if degrees is not None:
            duty = self.min_duty + span * degrees / self.degrees
        elif radians is not None:
            duty = self.min_duty + span * radians / math.radians(self.degrees)
        elif us is not None:
            duty = self._us2duty(us)
        elif duty is not None:
            pass
        else:
            return self.pca9685.duty(index)
        duty = min(self.max_duty, max(self.min_duty, int(duty)))
        self.pca9685.duty(index, duty)

    def release(self, index):
        self.pca9685.duty(index, 0)

    def position_duty(self, index, degrees=None, radians=None, us=None, duty=None):
        int_dutu=int(duty)
        self.pca9685.duty(index, int_dutu)



servos = Servos(pcai2c, address=0x40)#舵机控制板

#===头===
#1==-==2
#4==-==3
R_H=100

#4条腿坐标同时调节
def control_4_legs(x,y):
    global y1,y2,y3,y4
    global x1,x2,x3,x4
    y1 = y
    y2 = y
    y3 = y
    y4 = y
    x1=x
    x2=x
    x3=x
    x4=x


    caculate()
    servo_output()

#高度调节函数
def height(goal):
    global y1,y2,y3,y4
    global x1,x2,x3,x4
    global R_H
    global ges_y_1,ges_y_2,ges_y_3,ges_y_4
    while True:
        if R_H>goal:
            R_H=R_H-abs(R_H-goal)*Kp_H
        elif R_H<goal:
            R_H=R_H+abs(R_H-goal)*Kp_H
        if abs(R_H-goal)<1:
            break
        print("高度坐标",R_H)
        y1 = -R_H
        y2 = -R_H
        y3 = -R_H
        y4 = -R_H

        ges_y_1 = -R_H
        ges_y_2 = -R_H
        ges_y_3 = -R_H
        ges_y_4 = -R_H
        x1=0
        x2=0
        x3=0
        x4=0


        caculate()
        servo_output()


#===头===
#1==-==2
#4==-==3

def run_trot(r1,r4,r2,r3):    #小跑步态执行函数
    global t
    global x1,x2,x3,x4
    global y1,y2,y3,y4
    if t<=Ts*faai:
        sigma=2*pi*t/(faai*Ts)
        zep=h*(1-cos(sigma))/2
        xep_b=(xf-xs)*((sigma-sin(sigma))/(2*pi))+xs;
        xep_z=(xs-xf)*((sigma-sin(sigma))/(2*pi))+xf
        #输出y
        y1=ges_y_1+zep
        y2=ges_y_2
        y3=ges_y_3+zep
        y4=ges_y_4
        #输出x
        x1=-xep_z*r1
        x2=-xep_b*r2
        x3=-xep_z*r3
        x4=-xep_b*r4
    if t>Ts*faai and t<Ts:
        sigma=2*pi*(t-Ts*faai)/(faai*Ts)

        zep=h*(1-cos(sigma))/2;
        xep_b=(xf-xs)*((sigma-sin(sigma))/(2*pi))+xs;
        xep_z=(xs-xf)*((sigma-sin(sigma))/(2*pi))+xf
        #输出y
        y1=ges_y_1
        y2=ges_y_2+zep
        y3=ges_y_3
        y4=ges_y_4+zep
        #输出x
        x1=-xep_b*r1
        x2=-xep_z*r2
        x3=-xep_b*r3
        x4=-xep_z*r4
        #x1=0
        #x2=0
        #x3=0
        #x4=0
    print('=========')
    print('x1:',x1)
    print('x2:',x2)
    print('x3:',x3)
    print('x4:',x4)

    caculate()
    servo_output()



def trot(num):
    global t
    global x1,x2,x3,x4
    global y1,y2,y3,y4
    global xf,xs
    global ges_y_1,ges_y_4
    for i in range(abs(num)):
            while True:
                if t>=Ts:#一个完整的运动周期结束
                    t=0
                    break
                else:
                    t=t+speed
                    if num>0:
                        run_trot(1,1,1,1)
                        xf=40
                        xs=-10
                        #ges_y_1=-100
                        #ges_y_4=-100
                    elif num<0:
                        xf=20
                        xs=-20
                        #ges_y_1=-110
                        #ges_y_4=-110
                        run_trot(-1,-1,-1,-1)
            print("-------------循环"+str(i+1)+"-------------")

    x1=0
    x2=0
    x3=0
    x4=0
    caculate()
    servo_output()



time.sleep(1)           #延时等待
height(50)        #调节高度到50mm
height(110)       #调节高度到110mm
height(50)        #调节高度到50mm
height(110)       #调节高度到110mm
time.sleep(1)           #延时等待
trot(5)           #往前进5步
time.sleep(1)           #延时等待
trot(-5)          #往后退5步
