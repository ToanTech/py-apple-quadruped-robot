#ifndef _CONFIG_H
#define _CONFIG_H
#include "SCServo.h"

#define pi 3.1415
#define LF_H 1
#define LF_S 2
#define RF_H 3
#define RF_S 4
#define RR_H 5
#define RR_S 6
#define LR_H 7
#define LR_S 8

SCSCL sc;
/*默认速度 步长 设置*/
float l1 = 80; //大腿长(mm)
float l2 = 70; //小腿长(mm)
float h = 50;  //抬腿高度 设置
float xf = 30;
float xs = -10;

float Ts = 1;          //周期
float faai = 0.5;      //占空比
float speed = 0.025; //步频调节
/*校准模式 设置*/
int foot_init = 0;

/* 默认舵机中位值设置
狗腿子顺序(从1开始顺时针数)
===头===
1==-==2
4==-==3 */ 
//！！！注意！！！
//SCS0009舵机正对舵机时增加角度顺时针旋转
float init_1h = 98;  //1脚大腿 
float init_1s = 80;  //1脚小腿
float init_2h = 92;  //2脚大腿
float init_2s = 90;  //2脚小腿
float init_3h = 92;  //3脚大腿
float init_3s = 90;  //3脚小腿
float init_4h = 98;  //4脚大腿
float init_4s = 99;  //4脚小腿

//=============一些中间变量=============
float t = 0;
float init_x = 0;
float init_y = -100;
float x1 = init_x;
float y1 = init_y;
float x2 = init_x;
float y2 = init_y;
float x3 = init_x;
float y3 = init_y;
float x4 = init_x;
float y4 = init_y;

float ges_x_1 = 0;
float ges_x_2 = 0;
float ges_x_3 = 0;
float ges_x_4 = 0;

float ges_y_1 = init_y;
float ges_y_2 = init_y;
float ges_y_3 = init_y;
float ges_y_4 = init_y;

float shank1,shank2,shank3,shank4,ham1,ham2,ham3,ham4 = 0;

void IK(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4);
void servo_output();
int deg2pulse(int deg);
void gait_generator(int r1, int r2, int r3, int r4);
void trot(int num);
#endif
