此程序根据pypy_dog创始人————灯哥的四足机器人程序PADOG V1.1 BETA 1 2020506移植.
暂时没有移植gesture_control功能。
运行平台为arduino leonardo（有多余的串口可以用来用电脑调试）。
舵机为飞特串口舵机SCS0009,6V扭矩2.3kg.需要使用URT-1控制板连接。
可以使用菊花链链接，但是我画了连接器的板子。

程序结构：
	config.h 				同pypydog原版config.py 有改动
	kinematics.ino 			同pypydog原版position_control.py 有改动
	gait.ino				同pypydog原版trot.py  有改动
	main.ino				同pypydog原版main
	ServoOutputApi.ino		同pypydog原版position_control.py 舵机部分,有改动

	以下为飞特官方提供的程序
	INST
	SCS
	SCSCL
	SCSerial
	SCServo
	
开源协议：Apache License
	
Apache 协议介绍：
Apache License协议和BSD类似，同样鼓励代码共享和尊重原作者的著作权，同样允许代码修改，再发布（作为开源或商业软件）。需要满足的条件也和BSD类似：

需要给代码的用户一份Apache Licence
如果你修改了代码，需要在被修改的文件中说明
在延伸的代码中（修改和有源代码衍生的代码中）需要带有原来代码中的协议，商标，专利声明和其他原来作者规定需要包含的说明。
如果再发布的产品中包含一个Notice文件，则在Notice文件中需要带有Apache Licence。你可以在Notice中增加自己的许可，但不可以表现为对Apache Licence构成更改。