def init_servo_mov():
    global init_1h,init_1s,init_2h,init_2s,init_3h,init_3s,init_4h,init_4s
    #print(init_1s)
    #腿1
    servos.position(4, degrees=init_1h)  # 腿1大腿
    servos.position(5, degrees=init_1s)  # 腿1小腿
    #腿2
    servos.position(6, degrees=init_2h)  # 腿2大腿
    servos.position(7, degrees=init_2s)  # 腿2小腿
    #腿3
    servos.position(8, degrees=init_3h)  # 腿3大腿
    servos.position(9, degrees=init_3s)  # 腿3小腿
    #腿4
    servos.position(10, degrees=init_4h)  # 腿4大腿
    servos.position(11, degrees=init_4s)  # 腿4小腿

#===头===
#1==-==2
#4==-==3
def foot_init():
    global init_1h,init_1s,init_2h,init_2s,init_3h,init_3s,init_4h,init_4s
    print("PY-APPLE DOG 菠萝狗辅助脚调中系统")
    print("==================================")
    init_servo_mov()
    while True:
        print("#方向")
        print("#===头===")
        print("#1h/s==-==2h/s")
        print("#4h/s==-==3h/s")
        print("此刻，程序已经将舵机软件位置自动设置为大腿平行身体，小腿垂直大腿，请先按照这个位置安装机械结构，再进行微调")
        user_leg_num=input("请输入腿号【q(退出)/0(提示)】>>")
        if user_leg_num=="q":
            print("=============调中结果=============")
            print("init_1h:",init_1h)
            print("init_1s:",init_1s)
            print("init_2h:",init_2h)
            print("init_2s:",init_2s)
            print("init_3h:",init_3h)
            print("init_3s:",init_3s)
            print("init_4h:",init_4h)
            print("init_4s:",init_4s)
            print("=============调中结果=============")
            print("请记录这些调中结果，并在 config.py 中作对应更改，按 Enter 退出调中程序")
            input()
            break
        elif user_leg_num=="1h" or user_leg_num=="1s" or user_leg_num=="2h" or user_leg_num=="2s" or user_leg_num=="3h" or user_leg_num=="3s"or user_leg_num=="4h" or user_leg_num=="4s":
            while True:
                init_servo_mov()
                user_leg_die=input("请输入调平方向并回车【+/-/q(退出)】>>")
                exec("print(padog.init_"+user_leg_num+")")
                if user_leg_die=="+":
                    try:
                        exec("padog.init_"+user_leg_num+"="+"padog.init_"+user_leg_num+"+1")
                    except:
                        print("执行失败，请检查是否有输入错误")
                elif user_leg_die=="-":
                    try:
                        exec("padog.init_"+user_leg_num+"="+"padog.init_"+user_leg_num+"-1")
                    except:
                        print("执行失败，请检查是否有输入错误")
                elif user_leg_die=="q":
                    break
                else:
                    print("输入错误，请输入【+/-/q(退出)】，而非其它")
        elif user_leg_num=="0":
            print("1.腿号应为 腿号数+h 或 腿号数+s 格式。其中，h代表大腿，s代表小腿")
            print("2.如调整腿1大腿，输入1h,按 Enter 即可进入调节")
            print("3.进入调节后，按+或者-微调腿的位置")
            print("4.调节完成后，程序将输出腿1到腿4的初始化数值。将这些数值记录并在 config.py 中对应更改，即完成调平")
        else:
            print("输入错误，请输入1h、1s，2h、2s，3h、3s，4h、4s而非其它")