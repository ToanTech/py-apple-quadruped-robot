import padog
import time

#===头===
#1==-==2
#4==-==3
time.sleep(1)
padog.e_l_height(120,120,60,60)
time.sleep(1)
padog.e_l_height(60,60,120,120)
time.sleep(1)
padog.e_l_height(100,100,100,100)
time.sleep(1)
padog.e_l_height(110,60,60,110)
time.sleep(1)
padog.e_l_height(60,110,110,60)
time.sleep(1)
padog.e_l_height(100,100,100,100)
'''
time.sleep(1)           #延时等待
padog.height(50)        #调节高度到50mm
padog.height(110)       #调节高度到110mm
padog.height(50)        #调节高度到50mm
padog.height(110)       #调节高度到110mm
time.sleep(1)           #延时等待
padog.trot(5)           #往前进5步
time.sleep(1)           #延时等待
padog.trot(-5)          #往后退5步
'''