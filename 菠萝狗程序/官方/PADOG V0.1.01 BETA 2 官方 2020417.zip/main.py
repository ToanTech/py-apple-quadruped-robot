import padog
#padog.start_test(10)

padog.height(100)       #调节高度到10cm
padog.start_test(10)    #踏10步
for i in range(3):      #俯卧撑3下（调节高度）
    padog.height(130)   
    padog.height(50)
padog.height(80)
padog.start_test(10)
padog.height(120)
