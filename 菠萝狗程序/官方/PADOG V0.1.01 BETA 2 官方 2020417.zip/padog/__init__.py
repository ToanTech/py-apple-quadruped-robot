from math import *
from machine import I2C
from pyb import UART
from pyb import Pin
import time
#import _thread

#==============版本信息==================#
version="V0.1.01 BETA 1"

#打印版本信息
print("=============================")
print("PY-APPLE DOG TEST VER "+version)
print("=============================")
print("=========实现功能=========")
print("1、踏步 2、高度调节")
print("=========实现功能=========")

print("加载程序...")
Init_File_List=[".//padog//config.py",".//padog//execute//pca9685.py",".//padog//execute//servo.py",".//padog//execute//position_control.py",".//padog//gait//gait_test.py",".//padog//gait//gesture_control.py"]

#调试使用
for i in Init_File_List:
    exec(open(i).read())
    print(i)

print("程序加载完成...")


#预先执行函数
caculate()
servo_output()