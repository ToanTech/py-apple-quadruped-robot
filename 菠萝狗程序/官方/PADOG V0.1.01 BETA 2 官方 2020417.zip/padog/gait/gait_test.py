#===头===
#1==-==2
#4==-==3

def gait_test():
    global t
    global y1,y2,y3,y4
    if t<=Ts*faai:
        sigma=2*pi*t/(faai*Ts)
        zep=h*(1-cos(sigma))/2

        #输出y
        y1=ges_y_1+zep
        y2=ges_y_2
        y3=ges_y_3+zep
        y4=ges_y_4
    if t>Ts*faai and t<Ts:
        sigma=2*pi*(t-Ts)/(faai*Ts)
        zep=h*(1-cos(sigma))/2;

        #输出y
        y1=ges_y_1
        y2=ges_y_2+zep
        y3=ges_y_3
        y4=ges_y_4+zep
    print('=========')
    print('y1:',y1)
    print('y2:',y2)
    print('y3:',y3)
    print('y4:',y4)
    
    caculate()
    servo_output()
    
   
   
def start_test(num):
    global t
    for i in range(num):
            while True: 
                if t>=Ts:#一个完整的运动周期结束
                    t=0
                    break
                else:
                    t=t+speed
                    gait_test()
            print("-------------循环"+str(i+1)+"-------------")
                    